$(document).ready(function() {
  //   Hide the border by commenting out the variable below
  var $on = "section";
  $($on).css({
    background: "none",
    border: "none",
    "box-shadow": "none"
  });
});
